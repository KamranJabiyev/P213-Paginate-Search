﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using FrontToBack.DAL;
using FrontToBack.Extentions;
using FrontToBack.Helpers;
using FrontToBack.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace FrontToBack.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class SliderController : Controller
    {
        private readonly AppDbContext _db;
        private readonly IWebHostEnvironment _env;
        public SliderController(AppDbContext db, IWebHostEnvironment env)
        {
            _db = db;
            _env = env;
        }
        public IActionResult Index()
        {
            ViewBag.SlideCount = _db.Sliders.Count();
            return View(_db.Sliders);
        }

        public IActionResult Create()
        {
            if(_db.Sliders.Count()<3)
                return View();
            return Content("De sen ol");
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Slider slide)
        {
            if(ModelState["Photo"].ValidationState== ModelValidationState.Invalid)
            {
                return View();
            }

            if (!slide.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Not image!!!");
                return View();
            }

            if (slide.Photo.LessThan(2))
            {
                ModelState.AddModelError("Photo", "Size must be less than 2 Mb");
                return View();
            }

            //string path = @"E:\project\P213\FrontToBack\FrontToBack\wwwroot\img";
            string fileName =await slide.Photo.SavePhoto(_env.WebRootPath, "img");

            slide.Image = fileName;
            await _db.Sliders.AddAsync(slide);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Update(int id)
        {
            Slider slide = await _db.Sliders.FindAsync(id);
            if (slide == null)
            {
                return NotFound();
            }
            return View(slide);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int id,Slider slide)
        {
            if (slide.Photo != null)
            {
                if (!slide.Photo.IsImage())
                {
                    ModelState.AddModelError("Photo", "Not image!!!");
                    return View();
                }

                if (slide.Photo.LessThan(2))
                {
                    ModelState.AddModelError("Photo", "Size must be less than 2 Mb");
                    return View();
                }
                Slider slideDb = await _db.Sliders.FindAsync(id);
                //delete old image from folder
                FileHelper.DeleteImg(_env.WebRootPath, "img", slideDb.Image);
                //create new image in folder
                string fileName = await slide.Photo.SavePhoto(_env.WebRootPath, "img");
                slideDb.Image = fileName;
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int id)
        {
            Slider slide =await _db.Sliders.FindAsync(id);
            if (slide == null)
            {
                return NotFound();
            }
            return View(slide);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public async Task<IActionResult> DeletePost(int id)
        {
            if (_db.Sliders.Count() != 1)
            {
                Slider slide = await _db.Sliders.FindAsync(id);
                //string path = Path.Combine(_env.WebRootPath, "img", slide.Image);
                //if (System.IO.File.Exists(path))
                //{
                //    System.IO.File.Delete(path);
                //}
                FileHelper.DeleteImg(_env.WebRootPath, "img", slide.Image);
                _db.Sliders.Remove(slide);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return Content("Agillisan  daaa indiii");
        }
    }
}