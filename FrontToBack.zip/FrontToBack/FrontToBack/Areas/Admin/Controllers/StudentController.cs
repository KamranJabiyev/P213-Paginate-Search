﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBack.DAL;
using FrontToBack.Models;
using Microsoft.AspNetCore.Mvc;

namespace FrontToBack.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class StudentController : Controller
    {
        private readonly AppDbContext _db;
        public StudentController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index(int? page)
        {
            
            ViewBag.PageCount = Math.Ceiling((decimal)_db.Students.Count() / 3);
            if (page == null)
            {
                ViewBag.Page = 0;
                return View(_db.Students.Take(3));
            }
            ViewBag.Page = page;
            return View(_db.Students.Skip(3*(int)page).Take(3));

        }

        [HttpPost,ValidateAntiForgeryToken]
        public IActionResult Index(string search)
        {
            ViewBag.Page = 0;
            ViewBag.PageCount = Math.Ceiling((decimal)_db.Students.Count() / 3);

            if (search == null)
            {
                ModelState.AddModelError("", "Please enter something !");
                return View(_db.Students.Take(3));
            }
            return View(_db.Students.Where(s=>s.Name.Contains(search)||s.Surname.Contains(search)).Take(3));
        }

        public IActionResult Detail(int id)
        {
            Student stu = _db.Students.FirstOrDefault(s => s.Id == id);
            if (stu == null)
            {
                return NotFound();
            }
            return View(stu);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Student stu)
        {
            //Model binding
            if (!ModelState.IsValid)
            {
                return View(stu);
            }

            await _db.Students.AddAsync(stu);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Delete(int id)
        {
            Student stu = _db.Students.FirstOrDefault(s => s.Id == id);
            if (stu == null)
            {
                return NotFound();
            }
            return View(stu);
        }

        [HttpPost]
        [ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeletePost(int id)
        {
            Student stu = _db.Students.FirstOrDefault(s => s.Id == id);
            if (stu == null)
            {
                return NotFound();
            }
            _db.Students.Remove(stu);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Update(int id)
        {
            Student stu =await _db.Students.FindAsync(id);
            if (stu == null)
            {
                return NotFound();
            }
            return View(stu);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int id,Student stu)
        {
            //Student studentDb = await _db.Students.FindAsync(id);
            //if (studentDb == null)
            //{
            //    return NotFound();
            //}
            //studentDb.Name = stu.Name;
            //studentDb.Surname = stu.Surname;
            //studentDb.Description = stu.Description;
            _db.Entry(stu).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}