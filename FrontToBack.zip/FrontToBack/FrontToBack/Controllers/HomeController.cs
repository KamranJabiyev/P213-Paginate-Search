﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FrontToBack.DAL;
using FrontToBack.Models;
using FrontToBack.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace FrontToBack.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _db;
        public HomeController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            //Response.Cookies.Append("student", "Memmed", new CookieOptions { MaxAge = TimeSpan.FromMinutes(20) });
            //HttpContext.Session.SetString("group","p213 bezdirib meni!!!");
            HomeVM home = new HomeVM
            {
                Sliders=_db.Sliders,
                SliderText=_db.SliderTexts.First(s=>s.Id==1),
                Categories=_db.Categories,
                Products=_db.Products.Take(8),
                Abouts=_db.Abouts.First(a=>a.Id==1)
            };
            return View(home);
        }

        public async Task<IActionResult> AddBasket(int id)
        {
            Product product =await _db.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            List<BasketProVM> list;
            string currentBasket = HttpContext.Session.GetString("basket");
            if (currentBasket == null)
            {
                list = new List<BasketProVM>();
            }
            else
            {
                list = JsonConvert.DeserializeObject<List<BasketProVM>>(currentBasket);
            }

            var checkPro = list.FirstOrDefault(p => p.Id == id);
            if (checkPro == null)
            {
                BasketProVM basketPro = new BasketProVM
                {
                    Id = product.Id,
                    Name = product.Name,
                    Image = product.Image,
                    Price = product.Price,
                    Count = 1
                };
                list.Add(basketPro);
            }
            else
            {
                checkPro.Count += 1;
            }
            
            string basket = JsonConvert.SerializeObject(list);
            HttpContext.Session.SetString("basket",basket);
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Basket()
        {
            //string cookie = Request.Cookies["student"];
            //string session = HttpContext.Session.GetString("group");
            //return Content(HttpContext.Session.GetString("basket"));
            string basket = HttpContext.Session.GetString("basket");
            return View(JsonConvert.DeserializeObject<List<BasketProVM>>(basket));
        }
    }
}